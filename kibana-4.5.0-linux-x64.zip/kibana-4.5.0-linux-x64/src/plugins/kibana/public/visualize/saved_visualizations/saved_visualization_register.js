define(function (require) {
  return function savedVisualizationFn(savedVisualizations) {
    return savedVisualizations;
  };
});
