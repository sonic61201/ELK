define(function (require) {
  const _ = require('lodash');

  return {
    order: 3,
    name: 'status',
    display: 'Status',
    url: '/status'
  };
});
